<?php
define('EMAIL', 'administration@univ-mosta.tech
');
define('PASS', 'stidia27');