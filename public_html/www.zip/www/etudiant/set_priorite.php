<?php

include "db.php";

  if(isset($_POST['submit'])){
    $ids = array_keys($_POST['sujet_id']);
    
    foreach ($ids as $id) {
     
     $priorité = mysqli_real_escape_string($link,$_POST['priorité'][$id]);
     $sujet_id = mysqli_real_escape_string($link,$_POST['sujet_id'][$id]);
     $etudiant_id = mysqli_real_escape_string($link,$_POST['etudiant_id'][$id]);
     $id = mysqli_real_escape_string($link,$id);
    $update = mysqli_query($link,"update choix set priorité ='$priorité' where etudiant_id ='$etudiant_id' and sujet_id = '$sujet_id'");
    }



    if ($update) {
 
    $result=1;
      header("location:".$_SERVER['HTTP_REFERER']."?result=".urlencode($result));
      

  }
}

?>









