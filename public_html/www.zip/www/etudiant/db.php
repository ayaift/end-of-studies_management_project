<?php
$link = mysqli_connect("127.0.0.2", "univmost_madjid", "madjid", "univmost_madjid");
$link -> set_charset("utf8");
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}