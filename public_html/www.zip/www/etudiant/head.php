<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="../css1/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../admin.css">
	<link rel="stylesheet" type="text/css" href="prof.css">
	<link rel="stylesheet" type="text/css" href="ordre.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://kit.fontawesome.com/0c03620f7c.js" crossorigin="anonymous"></script>
	<script src="ordre.js"></script>

	<!--<link rel="stylesheet" type="text/css" href="css/mdb.dark.min.css">-->
</head>