<div class="container-fluid border" style="margin-top: 4px;background-color: #f9bc91">
  <div class="d-flex justify-content-center footer">
    <h3>footer</h3>
  </div>
      </div>

  </div>
</div>
</div>