<nav class="navbar navbar-expand-lg navbar-light navbar">
  <div class="container">
  	<img src="fsei.png" alt="" width="30" height="30">
  <a class="navbar-brand" href="prof_sujet.php">FSEI</a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
     
        <li class="nav-item">
          <a class="nav-link" href="prof_sujet.php"> <i class="fas fa-lg fa-book"></i> les sujets</a>

        </li>

   <!--     <li class="nav-item">
          <a class="nav-link" href="prof_sujets_valide.php"> <i class="far fa-lg fa-check-square"></i> les sujets validé</a>
        </li>
 -->
        <li class="nav-item">
          <a class="nav-link" href="prof_ajouter_sujet.php"><i class="fas fa-lg fa-plus"></i> Ajouter sujet</a>
        </li>

      </ul>
        <ul class="nav navbar-nav flex-fill justify-content-end">
           <li class="dropdown left">


              <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                   <img src="gear.svg" alt="créer" width="23" height="20">
                   </a>
            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">

              <li><a class="dropdown-item" href="prof_profil.php"><i class="fas fa-lg fa-info-circle"></i>  information génerales</a></li>
            </ul>
                </li>

                    <li class="nav-item">
                       <a class="nav-link" href="deconnexion.php"> <img src="box-arrow-left.svg" alt="créer" width="25" height="25"></a>

                     </li>
                   </ul>

    </div>
  </div>

</nav>
