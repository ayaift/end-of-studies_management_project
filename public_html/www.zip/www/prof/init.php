<?php
session_start();
include 'db.php';

define('PROJECT_NAME', 'FSEI');
